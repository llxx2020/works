package com.dyx.voice.inter;

public class Volume {
    public int volumePercent = -1;
    public int volume = -1;
    public String origalJson;
}
